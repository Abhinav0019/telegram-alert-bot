# Telegram Alert Bot

A simple Telegram bot to send breakout and swing alerts for traders.
